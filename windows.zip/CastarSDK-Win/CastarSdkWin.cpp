﻿#include <iostream>
#include <Windows.h>

#ifdef  _WIN64
#define SDKLOADFILEDLL L"CastarSdkWin_64.dll"
#else
#define SDKLOADFILEDLL L"CastarSdkWin_386.dll"
#endif

//Declare the function pointer to start running the SDK
typedef BOOL(*endSdk)();

//Declare function pointer to end running SDK
typedef BOOL(*startSdk)(char* key);

HMODULE hand = NULL;

//Here is the unique identifier:Key
const char *keybuf = "InputYourKeys";

void InitSDKStart() {
	startSdk demoDllStart = (startSdk)GetProcAddress(hand, "startSDK");
	if (demoDllStart)
	{
		/*
		The SDK will always block when running successfully, 
		and will throw a Boolean error when an exception occurs.
		*/
		if (!demoDllStart((char *)keybuf))
		{
			std::cout << "startSDK Error\n";
		}
	}
	else
	{
		std::cout << "startSDK Error\n";
	}
}

int main(int argc, char *argv[])
{
	hand = LoadLibrary(SDKLOADFILEDLL);
	if (NULL == hand || INVALID_HANDLE_VALUE == hand) {
		std::cout << "LoadLibrary Error\n";
		return -1;
	}

	//The thread calls the InitSDKStart function to avoid blocking the main thread.
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InitSDKStart, NULL, 0, NULL);

	/*
	......
	Handle your own business logic here
	*/

	//When needed, call the end function
	endSdk demoDllEnd = (endSdk)GetProcAddress(hand, "stopSDK");
	if (demoDllEnd)
	{
		demoDllEnd();
	}
	else
	{
		std::cout << "startSDK Error\n";
	}

	std::cout << "End SDK Demo!\n";
}
