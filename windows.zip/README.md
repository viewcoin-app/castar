## windows Integrated Document

### Integration options

Supports:
Windows7-Windows11, 32 bits or 64 bits

#### SDK install
(1) StartSDK is an interface function that opens SDK, and it receives a char* parameter, which is your own unique identifier Key.

(2) StopSDK is a function that closes SDK interface functions without any parameters. It is executed when SDL is planned to be stopped.

(3) Load the corresponding DLL file according to the production environment, and you can freely define the DLL path.

(4) CastarSdkWin_ *. dll name can be changed, CastarSdk_ *. dll name cannot be changed.

```c++
  Example:Your CliendId is "CSK****FHQlUQZ"
```

```c++
 #include 
        #include 
        
        #ifdef  _WIN64
        #define SDKLOADFILEDLL L"CastarSdkWin_64.dll"
        #else
        #define SDKLOADFILEDLL L"CastarSdkWin_386.dll"
        #endif
        
        //Declare the function pointer to start running the SDK
        typedef BOOL(*endSdk)();
        
        //Declare function pointer to end running SDK
        typedef BOOL(*startSdk)(char* key);
        
        HMODULE hand = NULL;
        
        //Set the ClientId here
        const char *keybuf = "CSK****FHQlUQZ";
        
        void InitSDKStart() {
            startSdk demoDllStart = (startSdk)GetProcAddress(hand, "startSDK");
            if (demoDllStart)
            {
                /*
                The SDK will always block when running successfully, 
                and will throw a Boolean error when an exception occurs.
                */
                if (!demoDllStart((char *)keybuf))
                {
                    std::cout << "startSDK Error\n";
                }
            }
            else
            {
                std::cout << "startSDK Error\n";
            }
        }
        
        int main(int argc, char *argv[])
        {
            hand = LoadLibrary(SDKLOADFILEDLL);
            if (NULL == hand || INVALID_HANDLE_VALUE == hand) {
                std::cout << "LoadLibrary Error\n";
                return -1;
            }
        
            //The thread calls the InitSDKStart function to avoid blocking the main thread.
            CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InitSDKStart, NULL, 0, NULL);
        
            /*
            ......
            Handle your own business logic here
            */
        
            //When needed, call the end function
            endSdk demoDllEnd = (endSdk)GetProcAddress(hand, "stopSDK");
            if (demoDllEnd)
            {
                demoDllEnd();
            }
            else
            {
                std::cout << "startSDK Error\n";
            }
        
            std::cout << "End SDK Demo!\n";
        }
```

#### Attention:

1.The suffixes _64 and _386 correspond to 64 bit and 32-bit compilation environments, respectively. Please load the DLL appropriately according to the program compilation environment.


2.The startSDK function blocks execution. Please open a sub thread for execution, otherwise it will block the main thread.

3.CastarSdkWin_ *. dll depends on CastarSdk_ *. dll. When deploying in a production environment, please place both DLLs in a directory that the program can load.